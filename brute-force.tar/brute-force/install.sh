#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo -e "\e[31mThis script must be run as root!\e[0m"
   exit 1
fi

echo -e "\e[34m[*] Updating system and installing required tools...\e[0m"
apt update -y && apt install -y python3 python3-pip figlet lolcat chromium -y

clear
figlet "Setup Started" | lolcat

echo -e "\n\e[33m[*] Installing Python libraries...\e[0m"

LIBS=(
    "playwright"
    "colorama"
    "art"
    "selenium"
)

for lib in "${LIBS[@]}"; do
    echo -e "\e[36m[+] Installing: $lib\e[0m"
    pip install "$lib" --break-system-packages 2>/dev/null && echo -e "\e[32m✔ Successfully installed\e[0m" || echo -e "\e[31m✘ Installation failed\e[0m"
done

chmod 777 Facebook.py

echo -e "\n\e[32m✔ All operations completed successfully!\e[0m" | lolcat
